# 2. Installation de LogMonitor

Ce guide couvre l'installation de LogMonitor sur les distributions Linux courantes (Debian, Ubuntu, CentOS, Fedora, Arch, Kali).

## Prérequis

*   **Système d'exploitation** : Linux (supportant Systemd pour le mode daemon).
*   **Python** : Version 3.10 ou supérieure.
    *   Vérifier avec : `python3 --version`
*   **Droits** : Accès `sudo` (pour installer les dépendances système).

## Méthode Recommandée : Script Automatique

Le script `install.sh` gère tout pour vous : détection de la distribution, installation des dépendances (pipx) et configuration initiale.

1.  **Cloner le dépôt** (ou téléchargez les sources) :
    ```bash
    git clone https://github.com/Lil-grxpe/LogMonitor.git
    cd LogMonitor
    ```

2.  **Lancer l'installation** :
    ```bash
    ./install.sh
    ```

3.  **Suivre les instructions** :
    *   Le script installera `pipx` si nécessaire.
    *   Il vous demandera de confirmer le fichier de logs à surveiller (par défaut `/var/log/auth.log` ou `/var/log/secure`).
    *   Si vous n'avez pas les droits de lecture sur les logs, il vous proposera la commande à exécuter (ex: `sudo usermod -aG adm $USER`).

## Méthode Alternative : Installation Manuelle (Expert)

Si vous préférez installer manuellement via `pipx` :

```bash
# 1. Installer pipx (si absent)
sudo apt install pipx  # Debian/Ubuntu
# ou
sudo dnf install pipx  # Fedora/RHEL

# 2. Ajouter pipx au PATH
pipx ensurepath
source ~/.bashrc  # ou ~/.zshrc

# 3. Installer LogMonitor depuis le dossier source
cd LogMonitor
pipx install .
```

## Vérification de l'Installation

Une fois installé, vérifiez que la commande `logmonitor` est accessible :

```bash
logmonitor --version
```

Si la commande fonctionne, l'installation est réussie !

[< Précédent : Introduction](./01_Introduction.md) | [Suivant : Configuration >](./03_Configuration.md)
