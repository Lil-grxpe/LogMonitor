# 7. Dépannage et FAQ

Solutions aux problèmes les plus fréquents rencontrés avec LogMonitor.

## Problèmes Courants

### 🛑 "Permission denied" lors de la lecture des logs
**Symptôme** : LogMonitor démarre mais ne détecte rien, ou affiche une erreur d'accès au fichier `/var/log/auth.log`.
**Solution** : Votre utilisateur doit avoir le droit de lire les logs.
1.  Ajoutez votre utilisateur au groupe `adm` :
    ```bash
    sudo usermod -aG adm $USER
    ```
2.  Déconnectez-vous et reconnectez-vous, ou redémarrez la machine.

### 🐍 "Pipx not found"
**Symptôme** : La commande `install.sh` échoue car `pipx` est introuvable.
**Solution** :
*   Sur Debian/Ubuntu : `sudo apt install pipx`
*   Sur Fedora : `sudo dnf install pipx`
*   Ensuite, ajoutez-le au PATH : `pipx ensurepath` (puis relancez votre terminal).

### 🌐 Dashboard inaccessible
**Symptôme** : Impossible de se connecter à `http://127.0.0.1:5000`.
**Vérifications** :
1.  Le serveur est-il lancé ? (commande `logmonitor web`)
2.  Si vous êtes sur un serveur distant (VPS), le port 5000 est-il ouvert dans le pare-feu ?
3.  Vérifiez les erreurs dans le terminal où la commande a été lancée.

---

## FAQ

**LogMonitor envoie-t-il mes logs sur Internet ?**
Non. Tout reste 100% local sur votre machine. Aucune donnée ne sort.

**Puis-je surveiller plusieurs fichiers en même temps ?**
Dans la version actuelle, LogMonitor se concentre sur un fichier principal d'authentification (auth.log ou secure) pour la corrélation d'événements. Le support multi-fichiers simultanés est prévu pour une future version.

**Comment désinstaller LogMonitor ?**
```bash
pipx uninstall logmonitor
rm -rf ~/.local/share/logmonitor  # Nettoyage optionnel
```

[< Précédent : Architecture Technique](./06_Architecture_Technique.md) | [Retour au début : Introduction](./01_Introduction.md)
